import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-analyticDashboard',
  templateUrl: 'analyticDashboard.html'
})
export class Dashboard {

  constructor(public navCtrl: NavController) {

  }

}
